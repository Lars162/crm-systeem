<?php
session_start();
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $voornaam = $_POST['voornaam'];
    $tussenvoegsel = $_POST['tussenvoegsel'];
    $achternaam = $_POST['achternaam'];
    $email = $_POST['email'];
    $wachtwoord = md5($_POST['wachtwoord']);
    $rol = $_POST['rol'];

    $sql = "INSERT INTO medewerkers
    (voornaam, tussenvoegsel, achternaam, email, wachtwoord, rol)
    VALUES
    ('$voornaam', '$tussenvoegsel', '$achternaam', '$email', '$wachtwoord', '$rol')";

    $conn->query($sql);

    header("Location: medewerkers.php");
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Medewerker toevoegen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Nieuwe medewerker toevoegen
</h1>

<form method="POST">

<div class="mb-3">

<div class="mb-3">

<label class="form-label">
Voornaam
</label>

<input type="text"
name="voornaam"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Tussenvoegsel
</label>

<input type="text"
name="tussenvoegsel"
class="form-control">

</div>

<div class="mb-3">

<label class="form-label">
Achternaam
</label>

<input type="text"
name="achternaam"
class="form-control"
required>

</div>

</div>

<div class="mb-3">

<label class="form-label">
Email
</label>

<input type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Wachtwoord
</label>

<input type="password"
name="wachtwoord"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Rol
</label>

<select name="rol"
class="form-select">

<option value="medewerker">
Medewerker
</option>

<option value="verkoopmedewerker">
Verkoopmedewerker
</option>

<option value="afdelingshoofd">
Afdelingshoofd
</option>

</select>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="medewerkers.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>