<?php
session_start();
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $bedrijfsnaam = $_POST['bedrijfsnaam'];
    $contactpersoon = $_POST['contactpersoon'];
    $email = $_POST['email'];

    $sql = "INSERT INTO klanten
    (bedrijfsnaam, contactpersoon, email)

    VALUES

    ('$bedrijfsnaam', '$contactpersoon', '$email')";

    if ($conn->query($sql) === TRUE) {

        header("Location: klanten.php");
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Klant toevoegen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
👥 Nieuwe klant toevoegen
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Bedrijfsnaam
</label>

<input type="text"
name="bedrijfsnaam"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Contactpersoon
</label>

<input type="text"
name="contactpersoon"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Email
</label>

<input type="email"
name="email"
class="form-control"
required>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="klanten.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>