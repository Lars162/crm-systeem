<?php
session_start();
include 'database.php';

$klanten = $conn->query(
"SELECT * FROM klanten"
);

$opdrachten = $conn->query(
"SELECT * FROM opdrachten"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $klant_id = $_POST['klant_id'];
    $opdracht_id = $_POST['opdracht_id'];
    $datum = $_POST['datum'];
    $bedrag = $_POST['bedrag'];
    $status = $_POST['status'];

    $sql = "INSERT INTO facturen

    (klant_id,
    opdracht_id,
    datum,
    bedrag,
    status)

    VALUES

    ('$klant_id',
    '$opdracht_id',
    '$datum',
    '$bedrag',
    '$status')";

    $conn->query($sql);

    header("Location: facturen.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Factuur toevoegen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Nieuwe factuur
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Klant
</label>

<select name="klant_id"
class="form-select">

<?php while($klant = $klanten->fetch_assoc()) { ?>

<option value="<?php echo $klant['id']; ?>">

<?php echo $klant['bedrijfsnaam']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Opdracht
</label>

<select name="opdracht_id"
class="form-select">

<?php while($opdracht = $opdrachten->fetch_assoc()) { ?>

<option value="<?php echo $opdracht['id']; ?>">

<?php echo $opdracht['titel']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Datum
</label>

<input type="date"
name="datum"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Bedrag
</label>

<input type="number"
step="0.01"
name="bedrag"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Status
</label>

<select name="status"
class="form-select">

<option value="Verstuurd">
Verstuurd
</option>

<option value="Betaald">
Betaald
</option>

</select>

</div>

<button type="submit"
class="btn btn-success">

Factuur opslaan

</button>

<a href="facturen.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>