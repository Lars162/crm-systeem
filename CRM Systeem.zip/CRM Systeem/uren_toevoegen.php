<?php
session_start();
include 'database.php';

$opdrachten = $conn->query(
"SELECT * FROM opdrachten"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $medewerker_id = $_SESSION['id'];

    $opdracht_id = $_POST['opdracht_id'];
    $datum = $_POST['datum'];
    $aantal_uren = $_POST['aantal_uren'];
    $beschrijving = $_POST['beschrijving'];

    $sql = "INSERT INTO urenregistratie

    (medewerker_id,
    opdracht_id,
    datum,
    aantal_uren,
    beschrijving)

    VALUES

    ('$medewerker_id',
    '$opdracht_id',
    '$datum',
    '$aantal_uren',
    '$beschrijving')";

    $conn->query($sql);

    header("Location: uren.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Uren toevoegen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Uren toevoegen
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Opdracht
</label>

<select name="opdracht_id"
class="form-select">

<?php while($opdracht = $opdrachten->fetch_assoc()) { ?>

<option value="<?php echo $opdracht['id']; ?>">

<?php echo $opdracht['titel']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Datum
</label>

<input type="date"
name="datum"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Aantal uren
</label>

<input type="number"
step="0.5"
name="aantal_uren"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Beschrijving werkzaamheden
</label>

<textarea name="beschrijving"
class="form-control"
rows="4"></textarea>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="uren.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>