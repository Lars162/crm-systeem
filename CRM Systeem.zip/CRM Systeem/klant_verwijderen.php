<?php
include 'database.php';

$id = $_GET['id'];

$sql = "DELETE FROM klanten WHERE id=$id";

$conn->query($sql);

header("Location: klanten.php");
?>