<?php
session_start();
include 'database.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

if ($_SESSION['rol'] == 'medewerker') {
    die("Geen toegang");
}

$zoek = "";

if (isset($_GET['zoek'])) {

    $zoek = $_GET['zoek'];

    $sql = "SELECT * FROM klanten
            WHERE bedrijfsnaam LIKE '%$zoek%'
            OR contactpersoon LIKE '%$zoek%'
            OR email LIKE '%$zoek%'";

} else {

    $sql = "SELECT * FROM klanten";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Klanten</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
👥 Klanten beheren
</h1>

<div class="d-flex justify-content-between mb-4">

<a href="klant_toevoegen.php"
class="btn btn-primary">

+ Nieuwe klant

</a>

<form method="GET" class="d-flex">

<input type="text"
name="zoek"
class="form-control me-2"
placeholder="Zoek klant"
value="<?php echo $zoek; ?>">

<button type="submit"
class="btn btn-dark">

Zoeken

</button>

</form>

</div>

<table class="table table-hover table-bordered align-middle">

<tr class="table-dark">

<th>ID</th>
<th>Bedrijfsnaam</th>
<th>Contactpersoon</th>
<th>Email</th>
<th>Acties</th>

</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['bedrijfsnaam']; ?></td>
<td><?php echo $row['contactpersoon']; ?></td>
<td><?php echo $row['email']; ?></td>

<td>

<a href="klant_bewerken.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Bewerken

</a>

<a href="klant_verwijderen.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm">

Verwijderen

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>

</html>