<div class="sidebar">

<h2 class="logo">
UrenRegistratie
</h2>

<a href="index.php">

Dashboard

</a>

<a href="uren.php">

Urenregistratie

</a>

<?php if ($_SESSION['rol'] != 'medewerker') { ?>

<a href="klanten.php">

Klanten

</a>

<a href="opdrachten.php">

Opdrachten

</a>

<a href="medewerkers.php">

Medewerkers

</a>

<a href="rapportages.php">

Rapportages

</a>

<a href="facturen.php">

Facturen

</a>

<?php } ?>

<a href="logout.php"
class="logout-btn">

Uitloggen

</a>

</div>