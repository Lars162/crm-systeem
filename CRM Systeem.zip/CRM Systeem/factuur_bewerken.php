<?php
session_start();
include 'database.php';

$id = $_GET['id'];

$factuur = $conn->query(
"SELECT * FROM facturen WHERE id=$id"
);

$row = $factuur->fetch_assoc();

$klanten = $conn->query(
"SELECT * FROM klanten"
);

$opdrachten = $conn->query(
"SELECT * FROM opdrachten"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $klant_id = $_POST['klant_id'];
    $opdracht_id = $_POST['opdracht_id'];
    $datum = $_POST['datum'];
    $bedrag = $_POST['bedrag'];
    $status = $_POST['status'];

    $sql = "UPDATE facturen SET

    klant_id='$klant_id',
    opdracht_id='$opdracht_id',
    datum='$datum',
    bedrag='$bedrag',
    status='$status'

    WHERE id=$id";

    $conn->query($sql);

    header("Location: facturen.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Factuur bewerken</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Factuur bewerken
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Klant
</label>

<select name="klant_id"
class="form-select">

<?php while($klant = $klanten->fetch_assoc()) { ?>

<option value="<?php echo $klant['id']; ?>">

<?php echo $klant['bedrijfsnaam']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Opdracht
</label>

<select name="opdracht_id"
class="form-select">

<?php while($opdracht = $opdrachten->fetch_assoc()) { ?>

<option value="<?php echo $opdracht['id']; ?>">

<?php echo $opdracht['titel']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Datum
</label>

<input type="date"
name="datum"
class="form-control"
value="<?php echo $row['datum']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Bedrag
</label>

<input type="number"
step="0.01"
name="bedrag"
class="form-control"
value="<?php echo $row['bedrag']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Status
</label>

<select name="status"
class="form-select">

<option value="Verstuurd">
Verstuurd
</option>

<option value="Betaald">
Betaald
</option>

</select>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="facturen.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>