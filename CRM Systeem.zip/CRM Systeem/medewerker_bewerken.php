<?php
session_start();
include 'database.php';

$id = $_GET['id'];

$sql = "SELECT * FROM medewerkers WHERE id=$id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $voornaam = $_POST['voornaam'];
$tussenvoegsel = $_POST['tussenvoegsel'];
$achternaam = $_POST['achternaam'];
$email = $_POST['email'];
$rol = $_POST['rol'];

$update = "UPDATE medewerkers SET
voornaam='$voornaam',
tussenvoegsel='$tussenvoegsel',
achternaam='$achternaam',
email='$email',
rol='$rol'
WHERE id=$id";
    $conn->query($update);

    header("Location: medewerkers.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Medewerker bewerken</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Medewerker bewerken
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Voornaam
</label>

<input type="text"
name="voornaam"
class="form-control"
value="<?php echo $row['voornaam']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Tussenvoegsel
</label>

<input type="text"
name="tussenvoegsel"
class="form-control"
value="<?php echo $row['tussenvoegsel']; ?>">

</div>

<div class="mb-3">

<label class="form-label">
Achternaam
</label>

<input type="text"
name="achternaam"
class="form-control"
value="<?php echo $row['achternaam']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Email
</label>

<input type="email"
name="email"
class="form-control"
value="<?php echo $row['email']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Rol
</label>

<select name="rol"
class="form-select">

<option value="medewerker"
<?php if($row['rol'] == 'medewerker') echo 'selected'; ?>>
Medewerker
</option>

<option value="verkoopmedewerker"
<?php if($row['rol'] == 'verkoopmedewerker') echo 'selected'; ?>>
Verkoopmedewerker
</option>

<option value="afdelingshoofd"
<?php if($row['rol'] == 'afdelingshoofd') echo 'selected'; ?>>
Afdelingshoofd
</option>

</select>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="medewerkers.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>