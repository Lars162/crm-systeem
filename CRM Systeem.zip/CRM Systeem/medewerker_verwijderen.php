<?php
include 'database.php';

$id = $_GET['id'];

$sql = "DELETE FROM medewerkers WHERE id=$id";

$conn->query($sql);

header("Location: medewerkers.php");
?>