<?php
session_start();
include 'database.php';

$error = "";

if(isset($_POST['login'])){

    $email = $_POST['email'];

    $wachtwoord = md5($_POST['wachtwoord']);

    $sql = "SELECT * FROM medewerkers
            WHERE werkmail='$email'
            AND wachtwoord='$wachtwoord'";

    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){

        $row = mysqli_fetch_assoc($result);

        $_SESSION['id'] = $row['id'];

        $_SESSION['naam'] =
        $row['voornaam'] . " " . $row['achternaam'];

        $_SESSION['rol'] = $row['rol'];

        header("Location: index.php");
        exit();

    } else {

        $error = "Verkeerde logingegevens";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<style>

body{
    background:#f4f6f9;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.login-box{
    width:400px;
    background:white;
    padding:40px;
    border-radius:20px;
}

</style>

</head>

<body>

<div class="login-box shadow">

<h2 class="text-center mb-4">

Login

</h2>

<?php if($error != "") { ?>

<div class="alert alert-danger">

<?php echo $error; ?>

</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label class="form-label">

Werkmail

</label>

<input type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">

Wachtwoord

</label>

<input type="password"
name="wachtwoord"
class="form-control"
required>

</div>

<button type="submit"
name="login"
class="btn btn-dark w-100">

Inloggen

</button>

</form>

</div>

</body>

</html>