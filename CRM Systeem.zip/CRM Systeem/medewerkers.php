<?php
session_start();
include 'database.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

if ($_SESSION['rol'] == 'medewerker') {
    die("Geen toegang");
}

$zoek = "";

if(isset($_GET['zoek'])){

    $zoek = $_GET['zoek'];

    $sql = "SELECT * FROM medewerkers

    WHERE naam LIKE '%$zoek%'
    OR email LIKE '%$zoek%'
    OR rol LIKE '%$zoek%'";

} else {

    $sql = "SELECT * FROM medewerkers";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Medewerkers</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Medewerkers beheren
</h1>

<div class="d-flex justify-content-between mb-4">

<a href="medewerker_toevoegen.php"
class="btn btn-warning">

+ Nieuwe medewerker

</a>

<form method="GET" class="d-flex">

<input type="text"
name="zoek"
class="form-control me-2"
placeholder="Zoek medewerker"
value="<?php echo $zoek; ?>">

<button type="submit"
class="btn btn-dark">

Zoeken

</button>

</form>

</div>

<table class="table table-hover table-bordered align-middle">

<tr class="table-dark">

<th>ID</th>
<th>Naam</th>
<th>Email</th>
<th>Rol</th>
<th>Acties</th>

</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td>
<?php echo $row['id']; ?>
</td>

<td>
<?php echo $row['naam']; ?>
</td>

<td>
<?php echo $row['email']; ?>
</td>

<td>

<span class="badge bg-primary">

<?php echo $row['rol']; ?>

</span>

</td>

<td>

<a href="medewerker_bewerken.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Bewerken

</a>

<a href="medewerker_verwijderen.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm">

Verwijderen

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>

</html>