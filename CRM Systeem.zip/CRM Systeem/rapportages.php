<?php
session_start();
include 'database.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

if ($_SESSION['rol'] == 'medewerker') {
    die("Geen toegang");
}

$totalUren = $conn->query(
"SELECT SUM(aantal_uren) AS totaal
 FROM urenregistratie"
);

$uren = $totalUren->fetch_assoc();

$totalOmzet = $conn->query(
"SELECT SUM(bedrag) AS omzet
FROM facturen"
);

$omzet = $totalOmzet->fetch_assoc();

$medewerkers = $conn->query(
"SELECT medewerkers.naam,
SUM(urenregistratie.aantal_uren) AS uren

FROM urenregistratie

JOIN medewerkers
ON urenregistratie.medewerker_id = medewerkers.id

GROUP BY medewerkers.naam"
);

$opdrachten = $conn->query(
"SELECT status, COUNT(*) AS aantal
FROM opdrachten
GROUP BY status"
);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Rapportages</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<h1 class="page-title">
Rapportages
</h1>

<div class="row g-4 mb-5">

<div class="col-md-6">

<div class="card shadow p-4 text-center">

<h5>
⏱ Totaal gewerkte uren
</h5>

<h1 class="display-5 fw-bold">

<?php echo $uren['totaal'] ?? 0; ?>

</h1>

<p>
Uren geregistreerd
</p>

</div>

</div>

<div class="col-md-6">

<div class="card shadow p-4 text-center">

<h5>
Totale omzet
</h5>

<h1 class="display-5 fw-bold text-success">

€ <?php echo $omzet['omzet'] ?? 0; ?>

</h1>

<p>
Totale opbrengst
</p>

</div>

</div>

</div>

<div class="container-box mb-5">

<h3 class="mb-4">
Uren per medewerker
</h3>

<table class="table table-hover table-bordered align-middle">

<tr class="table-dark">

<th>Medewerker</th>
<th>Uren</th>

</tr>

<?php while($row = $medewerkers->fetch_assoc()) { ?>

<tr>

<td>
<?php echo $row['naam']; ?>
</td>

<td>
<?php echo $row['uren']; ?>
</td>

</tr>

<?php } ?>

</table>

</div>

<div class="container-box">

<h3 class="mb-4">
Opdrachten status
</h3>

<table class="table table-hover table-bordered align-middle">

<tr class="table-dark">

<th>Status</th>
<th>Aantal</th>

</tr>

<?php while($row = $opdrachten->fetch_assoc()) { ?>

<tr>

<td>

<?php if($row['status'] == 'Actief') { ?>

<span class="badge bg-success">
Actief
</span>

<?php } else { ?>

<span class="badge bg-secondary">
Voldaan
</span>

<?php } ?>

</td>

<td>
<?php echo $row['aantal']; ?>
</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>

</html>