<?php
include 'database.php';

$id = $_GET['id'];

$sql = "DELETE FROM facturen WHERE id=$id";

$conn->query($sql);

header("Location: facturen.php");
?>