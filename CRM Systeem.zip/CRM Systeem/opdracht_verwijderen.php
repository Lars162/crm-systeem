<?php
include 'database.php';

$id = $_GET['id'];

$sql = "DELETE FROM opdrachten WHERE id=$id";

$conn->query($sql);

header("Location: opdrachten.php");
?>