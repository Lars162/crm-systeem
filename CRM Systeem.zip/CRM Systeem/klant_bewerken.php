<?php
session_start();
include 'database.php';

$id = $_GET['id'];

$sql = "SELECT * FROM klanten WHERE id=$id";

$result = $conn->query($sql);

$row = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $bedrijfsnaam = $_POST['bedrijfsnaam'];
    $contactpersoon = $_POST['contactpersoon'];
    $email = $_POST['email'];

    $update = "UPDATE klanten SET

    bedrijfsnaam='$bedrijfsnaam',
    contactpersoon='$contactpersoon',
    email='$email'

    WHERE id=$id";

    $conn->query($update);

    header("Location: klanten.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Klant bewerken</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
👥 Klant bewerken
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Bedrijfsnaam
</label>

<input type="text"
name="bedrijfsnaam"
class="form-control"
value="<?php echo $row['bedrijfsnaam']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Contactpersoon
</label>

<input type="text"
name="contactpersoon"
class="form-control"
value="<?php echo $row['contactpersoon']; ?>"
required>

</div>

<div class="mb-3">

<label class="form-label">
Email
</label>

<input type="email"
name="email"
class="form-control"
value="<?php echo $row['email']; ?>"
required>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="klanten.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>