<?php

$host = "localhost";
$user = "mijnuser";
$pass = "mijnwachtwoord";
$db = "urenregistratie3";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connectie mislukt: " . $conn->connect_error);
}

?>