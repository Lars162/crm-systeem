<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-fluid">

<h1 class="page-title">
Dashboard
</h1>

<div class="container-box mb-4">

<h4>
Welkom, <?php echo $_SESSION['naam']; ?>
</h4>

<p>
Rol:
<strong>
<?php echo $_SESSION['rol']; ?>
</strong>
</p>

</div>

<div class="row g-4">

<?php if ($_SESSION['rol'] != 'medewerker') { ?>

<div class="col-12 col-md-6">

<div class="card shadow p-4 h-100">

<h3>
Klanten
</h3>

<p>
Beheer alle klanten
</p>

<a href="klanten.php"
class="btn btn-primary">

Openen

</a>

</div>

</div>

<div class="col-12 col-md-6">

<div class="card shadow p-4 h-100">

<h3>
Opdrachten
</h3>

<p>
Bekijk opdrachten
</p>

<a href="opdrachten.php"
class="btn btn-success">

Openen

</a>

</div>

</div>

<div class="col-12 col-md-6">

<div class="card shadow p-4 h-100">

<h3>
Medewerkers
</h3>

<p>
Beheer medewerkers
</p>

<a href="medewerkers.php"
class="btn btn-warning">

Openen

</a>

</div>

</div>

<div class="col-12 col-md-6">

<div class="card shadow p-4 h-100">

<h3>
Rapportages
</h3>

<p>
Bekijk statistieken
</p>

<a href="rapportages.php"
class="btn btn-info">

Openen

</a>

</div>

</div>

<?php } ?>

<div class="col-12">

<div class="card shadow p-4">

<h3>
Urenregistratie
</h3>

<p>
Registreer gewerkte uren
</p>

<a href="uren.php"
class="btn btn-dark">

Openen

</a>

</div>

</div>

</div>

</div>

</div>

</body>

</html>