<?php
include 'database.php';

$id = $_GET['id'];

$sql = "DELETE FROM urenregistratie WHERE id=$id";

$conn->query($sql);

header("Location: uren.php");
?>