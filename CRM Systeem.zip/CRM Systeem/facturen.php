<?php
session_start();
include 'database.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

if ($_SESSION['rol'] == 'medewerker') {
    die("Geen toegang");
}

$sql = "SELECT facturen.*,
        klanten.bedrijfsnaam,
        opdrachten.titel

        FROM facturen

        JOIN klanten
        ON facturen.klant_id = klanten.id

        JOIN opdrachten
        ON facturen.opdracht_id = opdrachten.id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Facturen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Facturen
</h1>

<div class="d-flex justify-content-between mb-4">

<a href="factuur_toevoegen.php"
class="btn btn-primary">

+ Nieuwe factuur

</a>

</div>

<table class="table table-hover table-bordered align-middle">

<tr class="table-dark">

<th>ID</th>
<th>Klant</th>
<th>Opdracht</th>
<th>Datum</th>
<th>Bedrag</th>
<th>Status</th>
<th>Acties</th>

</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td>
<?php echo $row['id']; ?>
</td>

<td>
<?php echo $row['bedrijfsnaam']; ?>
</td>

<td>
<?php echo $row['titel']; ?>
</td>

<td>
<?php echo $row['datum']; ?>
</td>

<td>
€ <?php echo $row['bedrag']; ?>
</td>

<td>

<?php if($row['status'] == 'Betaald') { ?>

<span class="badge bg-success">

Betaald

</span>

<?php } else { ?>

<span class="badge bg-warning text-dark">

Verstuurd

</span>

<?php } ?>

</td>

<td>

<a href="factuur_bekijken.php?id=<?php echo $row['id']; ?>"
class="btn btn-primary btn-sm">

Bekijken

</a>

<a href="factuur_bewerken.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Bewerken

</a>

<a href="factuur_verwijderen.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm">

Verwijderen

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>

</html>