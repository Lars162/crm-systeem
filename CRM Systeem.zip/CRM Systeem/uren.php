<?php
session_start();
include 'database.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

$zoek = "";

if(isset($_GET['zoek'])){

    $zoek = $_GET['zoek'];

    $sql = "SELECT urenregistratie.*,
            medewerkers.naam,
            opdrachten.titel

            FROM urenregistratie

            JOIN medewerkers
            ON urenregistratie.medewerker_id = medewerkers.id

            JOIN opdrachten
            ON urenregistratie.opdracht_id = opdrachten.id

            WHERE medewerkers.naam LIKE '%$zoek%'
            OR opdrachten.titel LIKE '%$zoek%'
            OR urenregistratie.beschrijving LIKE '%$zoek%'
            OR urenregistratie.datum LIKE '%$zoek%'";

} else {

    $sql = "SELECT urenregistratie.*,
            medewerkers.naam,
            opdrachten.titel

            FROM urenregistratie

            JOIN medewerkers
            ON urenregistratie.medewerker_id = medewerkers.id

            JOIN opdrachten
            ON urenregistratie.opdracht_id = opdrachten.id";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Urenregistratie</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Urenregistratie
</h1>

<div class="d-flex justify-content-between mb-4">

<a href="uren_toevoegen.php"
class="btn btn-dark">

+ Uren toevoegen

</a>

<form method="GET" class="d-flex">

<input type="text"
name="zoek"
class="form-control me-2"
placeholder="Zoek urenregistratie"
value="<?php echo $zoek; ?>">

<button type="submit"
class="btn btn-primary">

Zoeken

</button>

</form>

</div>

<table class="table table-hover table-bordered align-middle">

<tr class="table-dark">

<th>Medewerker</th>
<th>Opdracht</th>
<th>Datum</th>
<th>Uren</th>
<th>Beschrijving</th>
<th>Acties</th>

</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td>
<?php echo $row['naam']; ?>
</td>

<td>
<?php echo $row['titel']; ?>
</td>

<td>
<?php echo $row['datum']; ?>
</td>

<td>
<?php echo $row['aantal_uren']; ?>
</td>

<td>
<?php echo $row['beschrijving']; ?>
</td>

<td>

<a href="uren_bewerken.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Bewerken

</a>

<a href="uren_verwijderen.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm">

Verwijderen

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>

</html>