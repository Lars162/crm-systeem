<?php
session_start();
include 'database.php';

$id = $_GET['id'];

$sql = "SELECT facturen.*,
        klanten.bedrijfsnaam,
        klanten.email,
        opdrachten.titel

        FROM facturen

        JOIN klanten
        ON facturen.klant_id = klanten.id

        JOIN opdrachten
        ON facturen.opdracht_id = opdrachten.id

        WHERE facturen.id = $id";

$result = $conn->query($sql);

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Factuur bekijken</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

<style>

.factuur-box{
    background:white;
    padding:50px;
    border-radius:20px;
}

@media print {

.sidebar,
.btn{
    display:none;
}

.main-content{
    margin-left:0;
    padding:0;
}

body{
    background:white;
}

}

</style>

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="factuur-box shadow">

<div class="d-flex justify-content-between mb-5">

<div>

<h1>
FACTUUR
</h1>

<p>
Factuurnummer:
<strong>
#<?php echo $row['id']; ?>
</strong>
</p>

</div>

<div class="text-end">

<h4>
UrenRegistratie
</h4>

<p>
Bedrijfsadministratie
</p>

</div>

</div>

<hr>

<div class="row mb-5">

<div class="col-md-6">

<h5>
Klantgegevens
</h5>

<p>

<strong>
<?php echo $row['bedrijfsnaam']; ?>
</strong>

<br>

<?php echo $row['email']; ?>

</p>

</div>

<div class="col-md-6 text-end">

<h5>
Factuur informatie
</h5>

<p>

Datum:
<strong>
<?php echo $row['datum']; ?>
</strong>

<br>

Status:
<strong>
<?php echo $row['status']; ?>
</strong>

</p>

</div>

</div>

<table class="table table-bordered">

<tr class="table-dark">

<th>Opdracht</th>
<th>Bedrag</th>

</tr>

<tr>

<td>
<?php echo $row['titel']; ?>
</td>

<td>
€ <?php echo $row['bedrag']; ?>
</td>

</tr>

</table>

<div class="text-end mt-5">

<h3>

Totaal:
€ <?php echo $row['bedrag']; ?>

</h3>

</div>

<div class="mt-5">

<button onclick="window.print()"
class="btn btn-dark">

🖨 Factuur printen

</button>

<a href="facturen.php"
class="btn btn-secondary">

Terug

</a>

</div>

</div>

</div>

</body>

</html>
