<?php
session_start();
include 'database.php';

$klanten = $conn->query("SELECT * FROM klanten");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $klant_id = $_POST['klant_id'];
    $titel = $_POST['titel'];
    $status = $_POST['status'];
    $uurprijs = $_POST['uurprijs'];

    $sql = "INSERT INTO opdrachten
    (klant_id, titel, status, uurprijs)

    VALUES

    ('$klant_id', '$titel', '$status', '$uurprijs')";

    $conn->query($sql);

    header("Location: opdrachten.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Opdracht toevoegen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<?php include 'includes/navbar.php'; ?>

<div class="main-content">

<div class="container-box">

<h1 class="page-title">
Nieuwe opdracht
</h1>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Klant
</label>

<select name="klant_id"
class="form-select">

<?php while($klant = $klanten->fetch_assoc()) { ?>

<option value="<?php echo $klant['id']; ?>">

<?php echo $klant['bedrijfsnaam']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Titel opdracht
</label>

<input type="text"
name="titel"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Status
</label>

<select name="status"
class="form-select">

<option value="Actief">
Actief
</option>

<option value="Voldaan">
Voldaan
</option>

</select>

</div>

<div class="mb-3">

<label class="form-label">
Uurprijs
</label>

<input type="number"
name="uurprijs"
class="form-control"
required>

</div>

<button type="submit"
class="btn btn-success">

Opslaan

</button>

<a href="opdrachten.php"
class="btn btn-secondary">

Terug

</a>

</form>

</div>

</div>

</body>

</html>